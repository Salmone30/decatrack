while true;
do
        node main.js 
        sleep 5
done