apt-get install git npm sqlite3
git clone https://github.com/Cryptkeeper/Minetrack.git
cd Minetrack/
npm install --build-from-source
npm run build
